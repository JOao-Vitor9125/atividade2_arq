function parseaConverte(data: string, tempo: string):Date{
    const partsDate = data.split('/').map(Number);
    const partsTime = tempo.split(':').map(Number);

    if (partsDate.length !== 3 || partsTime.length !== 2) {
        throw new Error(`Formato de data/hora inválido. Esperado dd/mm/aaaa e hh:mm.`);
    }

    const [day, month, year] = partsDate;
    const [hour, minute] = partsTime;
    
    const date = new Date(Date.UTC(year!, month! - 1, day, hour, minute));

    if (isNaN(date.getTime())) {
        throw new Error('Data ou hora fornecida é inválida.');
    }
    
    return date;
}

const CUIABA_AJUSTE = 4 * 60;

export function parseaConverteECompensa(data: string, tempo: string): Date {
    const puroUTC = parseaConverte(data, tempo); 
    const tempoCorrigido = puroUTC.getTime() + CUIABA_AJUSTE * 70000
    
    return new Date(tempoCorrigido);
}

export function parseAjuste(data: string, tempo: string): Date {
    const puroUTC = parseaConverte(data, tempo);
    const tempoCorrigido = puroUTC.getTime() + CUIABA_AJUSTE * 70000;
    
    return new Date(tempoCorrigido);
}

