import {SQLiteDB} from "../repos/sqlite.ts";
import {Agendador} from "./agendador.ts";

export function createAgenda():Agendador{
    const repo= new SQLiteDB();
    const agenda = new Agendador(repo);

    return agenda;
}