import type { AppointREPO, Appointment,} from '../repos/apontamentoREPO.ts';

export class Agendador{
    private readonly apontamentos:AppointREPO;
    constructor(apontamentos: AppointREPO){
        this.apontamentos=apontamentos;
    }

    async listAll():Promise<Appointment[]>{
        return this.apontamentos.getAll(); 
    }

    async adicionar(id: number, startTime:Date, endTime:Date, description:string):Promise<void>{
        if(startTime.getTime() >= endTime.getTime()){
            throw new Error("horario de inicio posterior ao de termino do compromisso");
        }

        for(let existente of await this.listAll()){
            if(startTime.getTime() < existente.endTime.getTime() && endTime.getTime() > existente.startTime.getTime()){
                throw new Error("conflito de horarios: ja existe um compromisso ocorrendo nesse horario");
            }
        }

        const newCompromisso: Appointment = {
            id:Date.now(),
            startTime:startTime,
            endTime:endTime,
            description:description
        }

        await this.apontamentos.save(newCompromisso);
    }

}