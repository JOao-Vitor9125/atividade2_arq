import {open, Database} from 'sqlite';
import sqlite3 from 'sqlite3';

import type { AppointREPO, Appointment } from '../repos/apontamentoREPO.ts';


const DATABASE_FILE = 'scheduler.db';

export class SQLiteDB implements AppointREPO{
    private db: Promise<Database> | Database;

    private async init(){
        const db=await open({
            filename: DATABASE_FILE,
            driver: sqlite3.Database
        });

        await db.exec(`CREATE TABLE IF NOT EXISTS apontamentos(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            start_time TEXT NOT NULL,
            end_time TEXT NOTE NULL,
            description TEXT NOT NULL);`);
        return db;
    }

    private async getDb():Promise<Database>{
    if (this.db instanceof Promise) {
        this.db = await this.db;
    }

    return this.db as Database;
    }

    constructor(){
        this.db=this.init();
    }

    async save(compromisso:Appointment):Promise<void>{
        const db=await this.getDb();
        
        const querry = `INSERT INTO apontamentos 
        (start_time, end_time, description)
        VALUES (?, ?, ?);`;

        const startISO=compromisso.startTime.toISOString();
        const endISO= compromisso.endTime.toISOString();

        try{
            await db.run(querry, startISO, endISO, compromisso.description);      
        }
        catch(err){
            throw new Error(`Falha na execução: ${err}`);
        }
    }

    async getAll():Promise<Appointment[]>{
        const db= await this.getDb();

        const linhas = await db.all(`SELECT *
            FROM apontamentos
            ORDER BY start_time ASC`);
        
        const 
        compromissos:Appointment[]= linhas.map((linha:any) => ({
            id:linha.id,
            startTime:new Date(linha.start_time),
            endTime:new Date(linha.end_time),
            description:linha.description
        }));
        return compromissos;
    }
}
