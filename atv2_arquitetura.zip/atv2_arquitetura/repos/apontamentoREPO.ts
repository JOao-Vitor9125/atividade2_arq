import {SQLiteDB} from './sqlite.ts';


export interface AppointREPO{
    save(compromisso:Appointment):Promise<void>;
    getAll():Promise<Appointment[]>
}
export interface Appointment{
    id: number,
    startTime:Date,
    endTime:Date,
    description:string;
}

export class MemoryRepo implements AppointREPO{
    private compromissos: Appointment[]= [];

    async save(compromisso:Appointment):Promise<void>{
        this.compromissos.push(compromisso);
    }
    async getAll():Promise<Appointment[]> {
        return this.compromissos;
    }
}