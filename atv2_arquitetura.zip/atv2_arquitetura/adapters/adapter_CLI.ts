import {Command} from 'commander';
import {parseAjuste} from '../tools/utilitarios.ts';
import {createAgenda} from '../service/agendaSQL.ts';


const agenda = createAgenda();

const options: Intl.DateTimeFormatOptions ={
    timeZone: 'America/Sao_Paulo', 
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false 
};


const programa = new Command();


programa
    .command('add')
    .argument('<date>', 'data (dd/mm/aaaa)')
    .argument('<start>', 'inicio (hh:mm)')
    .argument('<end>', 'fim (hh:mm)')
    .argument('<description>', 'Descrição')
    .action(async (date:string, start:string, end:string, description:string)=>{
        try {
            const startUTC = parseAjuste(date, start);
            const endUTC = parseAjuste(date, end);

            await agenda.adicionar(Date.now(), startUTC, endUTC, description);
            console.log(`compromisso agendado: ${description}`);
        } catch (error) {
            console.error(`Erro: ${error}`); 
        }
    });

programa
    .command('listar compromissos')
    .action(async()=>{
        try {
            const compromissos= await agenda.listAll();
            if (compromissos.length === 0) {
                 console.log('Nenhum compromisso agendado.');
                 return;
            }   

            compromissos.forEach(c =>{
                console.log(`Descrição compromisso: ${c.description} | Inicio: ${c.startTime.toLocaleString('pt-BR', options)} | Final: ${c.endTime.toLocaleString('pt-BR', options)}`);
            })

        } catch (error) {
            console.error(`Erro: ${error}`);
        }
    });
    programa.parse(process.argv);