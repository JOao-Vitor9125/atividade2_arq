import  express from 'express';
import type { Request, Response } from 'express';
import {parseaConverteECompensa} from '../tools/utilitarios.ts';
import {createAgenda} from '../service/agendaSQL.ts';

const options: Intl.DateTimeFormatOptions = {
    timeZone: 'America/Sao_Paulo',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false 
};



const app = express();
const PORT = 3000;


const agenda = createAgenda();

app.use(express.json());


app.get('/compromisso', async (req:Request, res:Response) =>{
    try{
        const compromissos = await agenda.listAll();
        
        const compromissosFormatados = compromissos.map(c => ({
            id: c.id,
            description: c.description,
            data_inicio_local: c.startTime.toLocaleString('pt-BR', options), 
            data_fim_local: c.endTime.toLocaleString('pt-BR', options),
        }));
        
        return res.status(200).json(compromissosFormatados);
    }
    catch(error){
        return res.status(500).json({erro: "Erro interno desconhecido"});
    }
});

app.post('/compromisso', async(req:Request, res:Response) =>{
    const {data, start, end, descr}=req.body;

    if(!data || !start || !end || !descr){
            return res.status(400).json({erro: 'Os dados enviados estão incompletos'});
    }
    
    try{
        const startUTC = parseaConverteECompensa(data, start)
        const endUTC = parseaConverteECompensa(data, end);

        await agenda.adicionar(Date.now(),startUTC, endUTC, descr);

        return res.status(201).json('Compromisso adicionado à agenda');
    }
    catch(error){
        let errorMessage = 'Ocorreu um erro interno desconhecido.';
        let status:number;

        if (error instanceof Error) {
            errorMessage = error.message;
        
            if (errorMessage.includes('Conflito')) {
                status = 409; 
            } 
            else {
                status = 400; 
            }
        }
        else {
            status = 500;
            errorMessage = String(error);
        }
        return res.status(status).json({erro: errorMessage});
    }    

    
});

app.listen(PORT, () =>{
    console.log(`Servidor escutando em http://localhost:${PORT}`);
})

